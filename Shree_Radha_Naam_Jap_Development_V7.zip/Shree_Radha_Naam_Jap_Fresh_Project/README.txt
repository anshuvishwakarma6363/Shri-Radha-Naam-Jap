SHREE RADHA NAAM JAP — DEVELOPMENT BUILD V7
Package: com.shriradha.naamjap | Version: 7.0 | minSdk 23 | targetSdk 35

Implemented in source:
- Optional native PIN gate with salted PBKDF2-HMAC-SHA256 verifier.
- AndroidX BiometricPrompt using strong biometrics/device credential.
- AES-256/GCM encrypted Jap database blob stored in app-private SharedPreferences.
- Encryption key generated and retained by Android Keystore.
- One-time migration from prior WebView localStorage to encrypted native storage on Android.
- Web preview fallback uses localStorage when AndroidBridge is absent.
- Existing Jap UI, counting, history, diary and manual JSON export/import retained.

Important:
- This is a development source ZIP, not a verified APK or final release.
- Manual JSON export is currently plain JSON; encrypted backup file export/restore remains pending.
- Automatic local backup/version rotation, notifications/reminders, home widget, Panchang/festival data,
  progress image export and several advanced report/session features remain pending.
- PIN/biometric and encrypted persistence require compilation and on-device testing.
- No release signing key or signed release APK is included.
- User will perform final device testing.

Build workflow currently produces a debug APK.
No ads, analytics, Google Drive or cloud sync.
Export and safely retain a backup before uninstalling or clearing app data.
