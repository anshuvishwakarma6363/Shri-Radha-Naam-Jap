package com.shriradha.naamjap;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.graphics.Color;
import android.view.WindowManager;
import android.view.View;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.text.InputType;
import android.content.SharedPreferences;
import android.content.Context;
import android.os.Build;
import android.util.Base64;
import androidx.fragment.app.FragmentActivity;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.security.SecureRandom;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.security.MessageDigest;
import java.util.concurrent.Executor;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class MainActivity extends FragmentActivity {
    private WebView web;
    private FrameLayout root;
    private LinearLayout lockPanel;
    private EditText pinBox;
    private TextView lockMessage;
    private SharedPreferences securePrefs;
    private final String PREFS = "radha_secure_gate";
    private final String HASH = "pin_hash";
    private final String SALT = "pin_salt";
    private final String ENABLED = "pin_enabled";
    private final String DATA_PREFS = "radha_encrypted_data";
    private final String DATA_BLOB = "encrypted_blob";
    private final String KEY_ALIAS = "shree_radha_data_key_v1";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        securePrefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.rgb(255,247,237));
        getWindow().setNavigationBarColor(Color.rgb(255,247,237));
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        root = new FrameLayout(this);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        web.setBackgroundColor(Color.rgb(255,250,243));
        root.addView(web, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        if (securePrefs.getBoolean(ENABLED, false)) showLockScreen();
        else loadApp();
    }

    private void loadApp() {
        if (lockPanel != null) root.removeView(lockPanel);
        web.setVisibility(View.VISIBLE);
        if (web.getUrl() == null) web.loadUrl("file:///android_asset/index.html");
    }

    private void showLockScreen() {
        web.setVisibility(View.GONE);
        lockPanel = new LinearLayout(this);
        lockPanel.setOrientation(LinearLayout.VERTICAL);
        lockPanel.setGravity(Gravity.CENTER);
        lockPanel.setPadding(28,32,28,32);
        lockPanel.setBackgroundColor(Color.rgb(255,247,237));
        TextView title = new TextView(this);
        title.setText("ॐ  श्री राधा नाम जाप  ॐ");
        title.setTextColor(Color.rgb(84,27,43));
        title.setTextSize(23);
        title.setGravity(Gravity.CENTER);
        lockPanel.addView(title, new LinearLayout.LayoutParams(-1,-2));
        TextView subtitle = new TextView(this);
        subtitle.setText("अपना PIN दर्ज करें या fingerprint से खोलें");
        subtitle.setTextColor(Color.rgb(118,40,58));
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2);
        sp.topMargin = 20;
        lockPanel.addView(subtitle,sp);
        pinBox = new EditText(this);
        pinBox.setHint("4–8 digit PIN");
        pinBox.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pinBox.setGravity(Gravity.CENTER);
        pinBox.setTextSize(22);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1,-2);
        ep.topMargin = 22;
        lockPanel.addView(pinBox,ep);
        Button unlock = new Button(this);
        unlock.setText("Unlock");
        lockPanel.addView(unlock,new LinearLayout.LayoutParams(-1,-2));
        unlock.setOnClickListener(v -> {
            String pin = pinBox.getText().toString();
            if (verifyPin(pin)) loadApp();
            else { pinBox.setText(""); lockMessage.setText("गलत PIN — पुनः प्रयास करें"); }
        });
        Button fingerprint = new Button(this);
        fingerprint.setText("Use fingerprint / device biometrics");
        lockPanel.addView(fingerprint,new LinearLayout.LayoutParams(-1,-2));
        fingerprint.setOnClickListener(v -> launchBiometric());
        lockMessage = new TextView(this);
        lockMessage.setTextColor(Color.rgb(160,45,45));
        lockMessage.setGravity(Gravity.CENTER);
        lockPanel.addView(lockMessage,new LinearLayout.LayoutParams(-1,-2));
        root.addView(lockPanel,new FrameLayout.LayoutParams(-1,-1));
    }

    private byte[] derive(String pin, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pin.toCharArray(), salt, 120000, 256);
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
        finally { spec.clearPassword(); }
    }
    private boolean verifyPin(String pin) {
        if (pin == null || pin.length() < 4 || pin.length() > 8) return false;
        try {
            byte[] salt = Base64.decode(securePrefs.getString(SALT,""), Base64.NO_WRAP);
            byte[] expected = Base64.decode(securePrefs.getString(HASH,""), Base64.NO_WRAP);
            return MessageDigest.isEqual(expected, derive(pin,salt));
        } catch (Exception e) { return false; }
    }
    private boolean configurePin(String oldPin, String newPin) {
        if (newPin == null || !newPin.matches("[0-9]{4,8}")) return false;
        if (securePrefs.getBoolean(ENABLED,false) && !verifyPin(oldPin)) return false;
        try {
            byte[] salt = new byte[16]; new SecureRandom().nextBytes(salt);
            byte[] hash = derive(newPin,salt);
            securePrefs.edit().putString(SALT,Base64.encodeToString(salt,Base64.NO_WRAP))
                .putString(HASH,Base64.encodeToString(hash,Base64.NO_WRAP))
                .putBoolean(ENABLED,true).apply();
            return true;
        } catch (Exception e) { return false; }
    }
    private boolean disablePin(String pin) {
        if (!verifyPin(pin)) return false;
        securePrefs.edit().remove(SALT).remove(HASH).putBoolean(ENABLED,false).apply();
        return true;
    }
    private void launchBiometric() {
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                runOnUiThread(() -> loadApp());
            }
            @Override public void onAuthenticationError(int code, CharSequence message) {
                runOnUiThread(() -> lockMessage.setText(message));
            }
        });
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
            .setTitle("Shree Radha Naam Jap")
            .setSubtitle("Authenticate to open your Jap diary")
            .setAllowedAuthenticators(BiometricPrompt.Authenticators.BIOMETRIC_STRONG |
                                      BiometricPrompt.Authenticators.DEVICE_CREDENTIAL)
            .build();
        prompt.authenticate(info);
    }


    private SecretKey getOrCreateDataKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();
        }
        KeyGenerator kg = KeyGenerator.getInstance("AES", "AndroidKeyStore");
        android.security.keystore.KeyGenParameterSpec spec =
            new android.security.keystore.KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT |
                android.security.keystore.KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build();
        kg.init(spec);
        return kg.generateKey();
    }
    private String loadEncryptedData() {
        try {
            String blob = getSharedPreferences(DATA_PREFS, MODE_PRIVATE).getString(DATA_BLOB, "");
            if (blob.isEmpty()) return "";
            byte[] packed = Base64.decode(blob, Base64.NO_WRAP);
            if (packed.length < 13) return "";
            byte[] iv = java.util.Arrays.copyOfRange(packed, 0, 12);
            byte[] cipherText = java.util.Arrays.copyOfRange(packed, 12, packed.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateDataKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(cipherText), java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) { return ""; }
    }
    private boolean saveEncryptedData(String plainText) {
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateDataKey());
            byte[] iv = cipher.getIV();
            byte[] cipherText = cipher.doFinal(plainText.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            byte[] packed = new byte[iv.length + cipherText.length];
            System.arraycopy(iv, 0, packed, 0, iv.length);
            System.arraycopy(cipherText, 0, packed, iv.length, cipherText.length);
            return getSharedPreferences(DATA_PREFS, MODE_PRIVATE).edit()
                .putString(DATA_BLOB, Base64.encodeToString(packed, Base64.NO_WRAP)).commit();
        } catch (Exception e) { return false; }
    }

    public class AndroidBridge {
        @JavascriptInterface public void keepAwake(final boolean enabled) {
            runOnUiThread(() -> {
                if (enabled) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }
        @JavascriptInterface public boolean configurePin(String oldPin, String newPin) {
            return MainActivity.this.configurePin(oldPin,newPin);
        }
        @JavascriptInterface public boolean disablePin(String pin) {
            return MainActivity.this.disablePin(pin);
        }
        @JavascriptInterface public boolean isPinEnabled() {
            return securePrefs.getBoolean(ENABLED,false);
        }
        @JavascriptInterface public String loadEncryptedData() {
            return MainActivity.this.loadEncryptedData();
        }
        @JavascriptInterface public boolean saveEncryptedData(String data) {
            return MainActivity.this.saveEncryptedData(data == null ? "" : data);
        }
    }
    @Override public void onBackPressed() {
        if (lockPanel != null && lockPanel.getParent() != null) return;
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
