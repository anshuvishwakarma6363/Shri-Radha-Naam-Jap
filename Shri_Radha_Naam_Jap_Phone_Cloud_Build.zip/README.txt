# श्री राधा नाम जाप — Android project

## Build APK using only your Android phone (cloud build)
This project includes a GitHub Actions workflow. GitHub's servers compile the APK; you do not need Android Studio or a computer.

1. Download and extract this ZIP on your phone (Files app > Downloads > ZIP > Extract).
2. In Chrome, open https://github.com and sign in or create a free account.
3. Create a new repository named `Shri-Radha-Naam-Jap`. Set it to **Public** (recommended for the simplest free Actions setup). Do not add a README or license.
4. On the repository page, choose **Add file > Upload files**. Upload the *contents* of the extracted project folder, including the `.github` folder. If your phone's file picker hides dot-folders, use GitHub's web editor or a ZIP upload-capable repository interface; the `.github/workflows/android.yml` file is required.
5. Commit the files to the `main` branch.
6. Open the repository's **Actions** tab. Select **Build Shri Radha Naam Jap APK**, then **Run workflow** if it has not started automatically.
7. Wait for the workflow to finish successfully. Open the completed run, scroll to **Artifacts**, and download `Shri-Radha-Naam-Jap-APK`.
8. Extract that artifact ZIP. Tap `app-debug.apk` to install it. If Android asks, allow your browser/file manager to install unknown apps for this installation.

## App behavior
- Tap र, ा, ध, ा in sequence. Only the full word राधा adds one count.
- Every completed entry is shown as `राधा राधा - N`.
- Every 108 names completes one mala; the next mala starts automatically.
- Progress is saved locally on the phone.

## Important
The ZIP is Android source code plus a cloud-build workflow, not the APK itself. GitHub builds the APK on its servers. Keep the repository private if you prefer, but GitHub Actions availability and limits may differ by account.
